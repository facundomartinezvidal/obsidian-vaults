package com.uade.magiccafe.infrastructure.notification;

import com.uade.magiccafe.domain.model.observer.PedidoEstadoCambiadoEvent;
import com.uade.magiccafe.domain.model.observer.PedidoObserver;

public class ReportingPedidoObserver implements PedidoObserver {

    @Override
    public void actualizar(PedidoEstadoCambiadoEvent evento) {
        System.out.println("[REPORTING] Pedido #" + evento.getPedidoId()
                + " | " + evento.getEstadoAnterior()
                + " -> " + evento.getEstadoNuevo()
                + " | fecha=" + evento.getFechaCambio());
    }
}
