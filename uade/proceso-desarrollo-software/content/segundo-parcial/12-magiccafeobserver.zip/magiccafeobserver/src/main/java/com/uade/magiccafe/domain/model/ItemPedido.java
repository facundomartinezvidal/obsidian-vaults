package com.uade.magiccafe.domain.model;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "pedido_items")
public class ItemPedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pedido_id", nullable = false)
    private Pedido pedido;

    /*
     * Composite:
     * el item conserva referencia al vendible base del catalogo
     * Producto o Combo.
     */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "vendible_id", nullable = false)
    private Vendible vendibleBase;

    /*
     * Decorator:
     * los extras no se persisten como entidades separadas.
     * Guardamos una foto historica de lo que el cliente compro:
     * descripcion final, extras aplicados y precio final.
     */
    private String descripcion;

    private String extrasAplicados;

    private int cantidad;

    private double precioUnitario;

    private double subtotal;

    protected ItemPedido() {
    }

    public ItemPedido(
            Pedido pedido,
            Vendible vendibleBase,
            ItemVendible itemDecorado,
            String extrasAplicados,
            int cantidad) {
        if (pedido == null) {
            throw new IllegalArgumentException("El pedido es obligatorio");
        }

        if (vendibleBase == null) {
            throw new IllegalArgumentException("El vendible base es obligatorio");
        }

        if (itemDecorado == null) {
            throw new IllegalArgumentException("El item decorado es obligatorio");
        }

        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor a cero");
        }

        this.pedido = pedido;
        this.vendibleBase = vendibleBase;
        this.descripcion = itemDecorado.getNombre();
        this.extrasAplicados = extrasAplicados;
        this.cantidad = cantidad;
        this.precioUnitario = itemDecorado.calcularPrecio();
        this.subtotal = precioUnitario * cantidad;
    }

    public Vendible getVendibleBase() {
        return vendibleBase;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getExtrasAplicados() {
        return extrasAplicados;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public double getSubtotal() {
        return subtotal;
    }
}
