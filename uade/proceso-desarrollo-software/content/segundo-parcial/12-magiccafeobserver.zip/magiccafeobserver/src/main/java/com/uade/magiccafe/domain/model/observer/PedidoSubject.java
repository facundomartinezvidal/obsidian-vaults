package com.uade.magiccafe.domain.model.observer;

public interface PedidoSubject {
    void agregarObserver(PedidoObserver observer);
    void quitarObserver(PedidoObserver observer);
    void notificarObservers(PedidoEstadoCambiadoEvent evento);
}
