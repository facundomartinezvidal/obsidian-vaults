package com.uade.magiccafe.domain.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("HECHIZO")
public class DescuentoHechizo extends DescuentoStrategy {

    private double montoFijo;

    protected DescuentoHechizo() {
    }

    public DescuentoHechizo(double montoFijo) {
        this.montoFijo = montoFijo;
    }

    @Override
    public String getNombre() {
        return "Descuento hechizo $" + montoFijo;
    }

    @Override
    public double aplicar(double subtotal) {
        return Math.max(0, subtotal - montoFijo);
    }
}
