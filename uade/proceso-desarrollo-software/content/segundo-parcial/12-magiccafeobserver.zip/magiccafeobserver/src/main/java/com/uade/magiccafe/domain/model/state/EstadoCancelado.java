package com.uade.magiccafe.domain.model.state;

public class EstadoCancelado extends EstadoPedidoBase {

    @Override
    public String getNombre() {
        return "CANCELADO";
    }
}
