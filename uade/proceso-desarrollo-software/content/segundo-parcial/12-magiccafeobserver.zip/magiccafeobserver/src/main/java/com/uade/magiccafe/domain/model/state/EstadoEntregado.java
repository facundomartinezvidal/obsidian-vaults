package com.uade.magiccafe.domain.model.state;

public class EstadoEntregado extends EstadoPedidoBase {

    @Override
    public String getNombre() {
        return "ENTREGADO";
    }
}
