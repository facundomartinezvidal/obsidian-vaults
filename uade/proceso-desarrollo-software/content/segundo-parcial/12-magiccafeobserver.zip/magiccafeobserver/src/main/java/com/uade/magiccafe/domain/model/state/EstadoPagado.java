package com.uade.magiccafe.domain.model.state;

import com.uade.magiccafe.domain.model.Pedido;

public class EstadoPagado extends EstadoPedidoBase {

    @Override
    public String getNombre() {
        return "PAGADO";
    }

    @Override
    public void preparar(Pedido pedido) {
        pedido.cambiarEstado(new EstadoPreparando());
    }

    @Override
    public void cancelar(Pedido pedido) {
        pedido.cambiarEstado(new EstadoCancelado());
    }
}
