package com.uade.magiccafe.application.dto;

public class VendibleDTO {

    private final Long id;
    private final String nombre;
    private final double precio;
    private final String tipo;

    public VendibleDTO(Long id, String nombre, double precio, String tipo) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.tipo = tipo;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public String getTipo() {
        return tipo;
    }

    @Override
    public String toString() {
        return "[" + tipo + "] " + nombre + " - $" + precio;
    }
}
