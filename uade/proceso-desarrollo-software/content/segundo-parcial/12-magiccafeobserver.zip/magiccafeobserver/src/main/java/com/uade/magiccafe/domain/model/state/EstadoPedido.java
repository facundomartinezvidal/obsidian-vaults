package com.uade.magiccafe.domain.model.state;

import com.uade.magiccafe.domain.model.Pedido;

/*
 * State Pattern - State
 * Define las acciones posibles sobre un Pedido.
 */
public interface EstadoPedido {

    String getNombre();

    void pagar(Pedido pedido);

    void preparar(Pedido pedido);

    void entregar(Pedido pedido);

    void cancelar(Pedido pedido);
}
