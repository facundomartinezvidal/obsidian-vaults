package com.uade.magiccafe.domain.model;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;

/*
 * Composite Pattern - Component
 *
 * Vendible representa cualquier cosa que se puede vender en MagicCafe:
 * - Producto simple
 * - Combo compuesto por otros vendibles
 */
@Entity
@Table(name = "vendibles")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tipo_vendible")
public abstract class Vendible implements ItemVendible {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    protected String nombre;

    protected Vendible() {
    }

    protected Vendible(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre es obligatorio");
        }

        this.nombre = nombre;
    }

    public Long getId() {
        return id;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public abstract double calcularPrecio();

    public double getPrecio() {
        return calcularPrecio();
    }

    @Override
    public String toString() {
        return nombre + " - $" + calcularPrecio();
    }
}
