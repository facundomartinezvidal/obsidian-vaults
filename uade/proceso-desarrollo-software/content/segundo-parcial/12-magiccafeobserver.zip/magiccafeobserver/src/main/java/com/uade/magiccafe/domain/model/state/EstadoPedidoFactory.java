package com.uade.magiccafe.domain.model.state;

/*
 * Reconstruye el objeto State a partir del String persistido en DB.
 * Esto permite persistir el estado como texto y seguir usando polimorfismo en memoria.
 */
public class EstadoPedidoFactory {

    private EstadoPedidoFactory() {
    }

    public static EstadoPedido desdeNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            return new EstadoCreado();
        }

        return switch (nombre) {
            case "CREADO" -> new EstadoCreado();
            case "PAGADO" -> new EstadoPagado();
            case "PREPARANDO" -> new EstadoPreparando();
            case "ENTREGADO" -> new EstadoEntregado();
            case "CANCELADO" -> new EstadoCancelado();
            default -> throw new IllegalArgumentException("Estado de pedido desconocido: " + nombre);
        };
    }
}
