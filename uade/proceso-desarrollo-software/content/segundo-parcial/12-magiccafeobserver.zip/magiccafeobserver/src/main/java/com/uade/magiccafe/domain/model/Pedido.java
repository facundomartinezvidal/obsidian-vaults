package com.uade.magiccafe.domain.model;

import com.uade.magiccafe.domain.model.observer.PedidoEstadoCambiadoEvent;
import com.uade.magiccafe.domain.model.observer.PedidoObserver;
import com.uade.magiccafe.domain.model.observer.PedidoSubject;
import com.uade.magiccafe.domain.model.state.EstadoCreado;
import com.uade.magiccafe.domain.model.state.EstadoPedido;
import com.uade.magiccafe.domain.model.state.EstadoPedidoFactory;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PostLoad;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "pedidos")
public class Pedido implements PedidoSubject {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime fechaCreacion;

    private double subtotal;

    private double total;

    /*
     * State persistido como texto.
     * El objeto EstadoPedido es comportamiento de dominio en memoria.
     */
    @Column(nullable = false)
    private String estado = "CREADO";

    @Transient
    private EstadoPedido estadoActual = new EstadoCreado();

    /*
     * Observer Pattern: los observadores son comportamiento de runtime.
     * No se persisten porque pueden representar integraciones externas
     * como Email, Firebase o Reporting.
     */
    @Transient
    private List<PedidoObserver> observers = new ArrayList<>();

    @ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    @JoinColumn(name = "descuento_id", nullable = false)
    private DescuentoStrategy descuento;

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ItemPedido> items = new ArrayList<>();

    protected Pedido() {
    }

    public Pedido(DescuentoStrategy descuento) {
        if (descuento == null) {
            throw new IllegalArgumentException("El descuento es obligatorio");
        }

        this.fechaCreacion = LocalDateTime.now();
        this.descuento = descuento;
        cambiarEstado(new EstadoCreado());
    }

    @PostLoad
    private void reconstruirEstadoActual() {
        this.estadoActual = EstadoPedidoFactory.desdeNombre(this.estado);
    }

    public void agregarItem(
            Vendible vendibleBase,
            ItemVendible itemDecorado,
            String extrasAplicados,
            int cantidad) {
        if (!"CREADO".equals(estado)) {
            throw new IllegalStateException("Solo se pueden agregar items a pedidos en estado CREADO");
        }

        ItemPedido item = new ItemPedido(
                this,
                vendibleBase,
                itemDecorado,
                extrasAplicados,
                cantidad
        );

        items.add(item);
        recalcularTotales();
    }

    public void agregarVendible(Vendible vendible, int cantidad) {
        agregarItem(vendible, vendible, "Sin extras", cantidad);
    }

    public void recalcularTotales() {
        subtotal = items.stream()
                .mapToDouble(ItemPedido::getSubtotal)
                .sum();

        total = descuento.aplicar(subtotal);
    }

    public boolean estaVacio() {
        return items.isEmpty();
    }

    /*
     * State Pattern: el Pedido delega el comportamiento en su estado actual.
     */
    public void pagar() {
        estadoActual.pagar(this);
    }

    public void preparar() {
        estadoActual.preparar(this);
    }

    public void entregar() {
        estadoActual.entregar(this);
    }

    public void cancelar() {
        estadoActual.cancelar(this);
    }

    public void cambiarEstado(EstadoPedido nuevoEstado) {
        String estadoAnterior = this.estado;

        this.estadoActual = nuevoEstado;
        this.estado = nuevoEstado.getNombre();

        if (estadoAnterior != null && !estadoAnterior.equals(this.estado)) {
            notificarObservers(new PedidoEstadoCambiadoEvent(
                    this,
                    estadoAnterior,
                    this.estado
            ));
        }
    }

    @Override
    public void agregarObserver(PedidoObserver observer) {
        if (observer != null && !observers.contains(observer)) {
            observers.add(observer);
        }
    }

    @Override
    public void quitarObserver(PedidoObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notificarObservers(PedidoEstadoCambiadoEvent evento) {
        for (PedidoObserver observer : observers) {
            observer.actualizar(evento);
        }
    }

    public Long getId() {
        return id;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public double getTotal() {
        return total;
    }

    public String getEstado() {
        return estado;
    }

    public DescuentoStrategy getDescuento() {
        return descuento;
    }

    public List<ItemPedido> getItems() {
        return items;
    }
}
