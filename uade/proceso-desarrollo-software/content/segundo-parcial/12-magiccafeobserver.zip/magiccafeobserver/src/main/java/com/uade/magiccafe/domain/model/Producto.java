package com.uade.magiccafe.domain.model;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

/*
 * Composite Pattern - Leaf
 * Producto es una hoja: no contiene otros vendibles.
 */
@Entity
@DiscriminatorValue("PRODUCTO")
public class Producto extends Vendible {

    @Column(name = "precio_producto")
    private double precio;

    protected Producto() {
    }

    public Producto(String nombre, double precio) {
        super(nombre);

        if (precio <= 0) {
            throw new IllegalArgumentException("El precio debe ser mayor a cero");
        }

        this.precio = precio;
    }

    @Override
    public double calcularPrecio() {
        return precio;
    }
}
