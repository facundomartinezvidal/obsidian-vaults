package com.uade.magiccafe.application.dto;

public class DescuentoDTO {

    private final Long id;
    private final String nombre;

    public DescuentoDTO(Long id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
