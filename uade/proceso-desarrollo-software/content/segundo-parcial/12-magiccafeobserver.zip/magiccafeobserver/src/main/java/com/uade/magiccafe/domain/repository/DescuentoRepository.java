package com.uade.magiccafe.domain.repository;

import com.uade.magiccafe.domain.model.DescuentoStrategy;

public interface DescuentoRepository extends JpaRepository<DescuentoStrategy, Long> {
}
