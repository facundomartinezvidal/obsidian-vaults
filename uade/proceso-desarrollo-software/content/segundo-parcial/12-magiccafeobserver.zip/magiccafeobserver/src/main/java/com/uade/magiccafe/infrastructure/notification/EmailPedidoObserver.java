package com.uade.magiccafe.infrastructure.notification;

import com.uade.magiccafe.domain.model.observer.PedidoEstadoCambiadoEvent;
import com.uade.magiccafe.domain.model.observer.PedidoObserver;

public class EmailPedidoObserver implements PedidoObserver {

    @Override
    public void actualizar(PedidoEstadoCambiadoEvent evento) {
        System.out.println("[EMAIL] Pedido #" + evento.getPedidoId()
                + " cambió de " + evento.getEstadoAnterior()
                + " a " + evento.getEstadoNuevo()
                + ". Total: $" + evento.getTotalPedido());
    }
}
