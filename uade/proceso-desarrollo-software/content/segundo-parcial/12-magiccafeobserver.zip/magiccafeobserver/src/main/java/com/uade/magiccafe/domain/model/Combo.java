package com.uade.magiccafe.domain.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;

import java.util.ArrayList;
import java.util.List;

/*
 * Composite Pattern - Composite
 * Combo también es un Vendible, pero contiene otros Vendibles.
 */
@Entity
@DiscriminatorValue("COMBO")
public class Combo extends Vendible {

    @OneToMany(mappedBy = "combo", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<ComboItem> items = new ArrayList<>();

    protected Combo() {
    }

    public Combo(String nombre) {
        super(nombre);
    }

    public void agregarVendible(Vendible vendible, int cantidad) {
        if (vendible == null) {
            throw new IllegalArgumentException("El vendible es obligatorio");
        }

        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor a cero");
        }

        items.add(new ComboItem(this, vendible, cantidad));
    }

    @Override
    public double calcularPrecio() {
        return items.stream()
                .mapToDouble(ComboItem::calcularSubtotal)
                .sum();
    }

    public List<ComboItem> getItems() {
        return items;
    }
}
