package com.uade.magiccafe.domain.model.state;

import com.uade.magiccafe.domain.model.Pedido;

public class EstadoPreparando extends EstadoPedidoBase {

    @Override
    public String getNombre() {
        return "PREPARANDO";
    }

    @Override
    public void entregar(Pedido pedido) {
        pedido.cambiarEstado(new EstadoEntregado());
    }
}
