package com.uade.magiccafe.presentation.controller;

import com.uade.magiccafe.application.dto.DescuentoDTO;
import com.uade.magiccafe.application.dto.PedidoConfirmadoDTO;
import com.uade.magiccafe.application.dto.PedidoResumenDTO;
import com.uade.magiccafe.application.dto.VendibleDTO;
import com.uade.magiccafe.application.usecase.MagicCafeService;

import java.util.ArrayList;
import java.util.List;

public class MagicCafeController {

    private final MagicCafeService service;

    private final List<MagicCafeService.ItemPedidoRequest> itemsActuales =
            new ArrayList<>();

    public MagicCafeController(MagicCafeService service) {
        this.service = service;
    }

    public void inicializarDatosBase() { service.inicializarDatosBase(); }
    public List<VendibleDTO> listarVendibles() { return service.listarVendibles(); }
    public List<DescuentoDTO> listarDescuentos() { return service.listarDescuentos(); }

    public void agregarItem(
            Long vendibleId,
            int cantidad,
            boolean conLeche,
            boolean conCrema,
            boolean conCanela) {
        if (cantidad <= 0) {
            throw new RuntimeException("La cantidad debe ser mayor a cero");
        }

        itemsActuales.add(new MagicCafeService.ItemPedidoRequest(
                vendibleId,
                cantidad,
                conLeche,
                conCrema,
                conCanela
        ));
    }

    public void vaciarPedido() { itemsActuales.clear(); }

    public PedidoConfirmadoDTO confirmarPedido(Long descuentoId) {
        PedidoConfirmadoDTO dto = service.confirmarPedido(
                new ArrayList<>(itemsActuales),
                descuentoId
        );

        itemsActuales.clear();
        return dto;
    }

    public List<PedidoResumenDTO> listarPedidos() { return service.listarPedidos(); }

    public void pagarPedido(Long pedidoId) { service.pagarPedido(pedidoId); }
    public void prepararPedido(Long pedidoId) { service.prepararPedido(pedidoId); }
    public void entregarPedido(Long pedidoId) { service.entregarPedido(pedidoId); }
    public void cancelarPedido(Long pedidoId) { service.cancelarPedido(pedidoId); }
}
