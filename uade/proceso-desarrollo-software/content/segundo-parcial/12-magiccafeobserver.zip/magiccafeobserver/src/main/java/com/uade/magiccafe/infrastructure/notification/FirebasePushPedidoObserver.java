package com.uade.magiccafe.infrastructure.notification;

import com.uade.magiccafe.domain.model.observer.PedidoEstadoCambiadoEvent;
import com.uade.magiccafe.domain.model.observer.PedidoObserver;

public class FirebasePushPedidoObserver implements PedidoObserver {

    @Override
    public void actualizar(PedidoEstadoCambiadoEvent evento) {
        System.out.println("[FIREBASE PUSH] Tu pedido #" + evento.getPedidoId()
                + " ahora está en estado: " + evento.getEstadoNuevo());
    }
}
