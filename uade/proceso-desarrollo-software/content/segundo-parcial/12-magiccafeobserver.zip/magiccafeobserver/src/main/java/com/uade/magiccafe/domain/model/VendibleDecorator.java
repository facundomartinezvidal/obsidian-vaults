package com.uade.magiccafe.domain.model;

/*
 * Decorator Pattern - Decorator base
 *
 * Envuelve otro ItemVendible y permite agregar comportamiento sin modificar
 * Producto, Combo ni Pedido.
 */
public abstract class VendibleDecorator implements ItemVendible {

    protected final ItemVendible itemVendible;

    protected VendibleDecorator(ItemVendible itemVendible) {
        if (itemVendible == null) {
            throw new IllegalArgumentException("El item vendible es obligatorio");
        }

        this.itemVendible = itemVendible;
    }

    @Override
    public String getNombre() {
        return itemVendible.getNombre();
    }

    @Override
    public double calcularPrecio() {
        return itemVendible.calcularPrecio();
    }
}
