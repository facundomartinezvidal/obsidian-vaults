package com.uade.magiccafe.infrastructure.persistence.repository;

import com.uade.magiccafe.domain.model.DescuentoStrategy;
import com.uade.magiccafe.domain.repository.DescuentoRepository;

/*
 * No reimplementa CRUD.
 * Solo indica que este repository trabaja con DescuentoStrategy.
 */
public class DescuentoJpaRepository
        extends SimpleJpaRepository<DescuentoStrategy, Long>
        implements DescuentoRepository {

    public DescuentoJpaRepository() {
        super(DescuentoStrategy.class);
    }
}
