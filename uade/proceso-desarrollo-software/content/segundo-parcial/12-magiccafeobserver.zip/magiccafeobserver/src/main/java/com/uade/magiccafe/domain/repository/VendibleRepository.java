package com.uade.magiccafe.domain.repository;

import com.uade.magiccafe.domain.model.Vendible;

public interface VendibleRepository extends JpaRepository<Vendible, Long> {
}
