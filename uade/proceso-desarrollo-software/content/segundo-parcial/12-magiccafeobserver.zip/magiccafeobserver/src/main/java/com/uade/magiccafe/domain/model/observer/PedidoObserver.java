package com.uade.magiccafe.domain.model.observer;

public interface PedidoObserver {
    void actualizar(PedidoEstadoCambiadoEvent evento);
}
