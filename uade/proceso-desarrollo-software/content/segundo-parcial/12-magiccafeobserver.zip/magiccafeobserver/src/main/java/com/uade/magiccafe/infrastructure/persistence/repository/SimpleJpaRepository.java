package com.uade.magiccafe.infrastructure.persistence.repository;

import com.uade.magiccafe.domain.repository.JpaRepository;
import com.uade.magiccafe.infrastructure.persistence.jpa.JPAUtil;
import jakarta.persistence.EntityManager;

import java.util.List;
import java.util.Optional;

/*
 * Implementación genérica tipo JpaRepository, pero sin Spring Boot.
 *
 * Esta clase concentra save(), findById(), findAll(), delete() y deleteById().
 * Los repositorios concretos no tienen que volver a implementar el CRUD.
 */
public class SimpleJpaRepository<T, ID> implements JpaRepository<T, ID> {

    private final Class<T> entityClass;

    public SimpleJpaRepository(Class<T> entityClass) {
        this.entityClass = entityClass;
    }

    @Override
    public T save(T entity) {
        EntityManager em = JPAUtil.getEntityManager();

        try {
            em.getTransaction().begin();

            T saved = em.merge(entity);

            em.getTransaction().commit();

            return saved;

        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }

            throw ex;

        } finally {
            em.close();
        }
    }

    @Override
    public Optional<T> findById(ID id) {
        EntityManager em = JPAUtil.getEntityManager();

        try {
            return Optional.ofNullable(em.find(entityClass, id));

        } finally {
            em.close();
        }
    }

    @Override
    public List<T> findAll() {
        EntityManager em = JPAUtil.getEntityManager();

        try {
            return em.createQuery(
                    "FROM " + entityClass.getSimpleName(),
                    entityClass
            ).getResultList();

        } finally {
            em.close();
        }
    }

    @Override
    public void delete(T entity) {
        EntityManager em = JPAUtil.getEntityManager();

        try {
            em.getTransaction().begin();

            T managed = em.merge(entity);
            em.remove(managed);

            em.getTransaction().commit();

        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }

            throw ex;

        } finally {
            em.close();
        }
    }

    @Override
    public void deleteById(ID id) {
        EntityManager em = JPAUtil.getEntityManager();

        try {
            em.getTransaction().begin();

            T entity = em.find(entityClass, id);

            if (entity != null) {
                em.remove(entity);
            }

            em.getTransaction().commit();

        } catch (RuntimeException ex) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }

            throw ex;

        } finally {
            em.close();
        }
    }
}
