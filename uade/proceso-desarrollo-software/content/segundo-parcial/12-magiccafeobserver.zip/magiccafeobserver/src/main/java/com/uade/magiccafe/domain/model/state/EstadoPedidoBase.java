package com.uade.magiccafe.domain.model.state;

import com.uade.magiccafe.domain.model.Pedido;

/*
 * Clase base opcional para evitar repetir errores en todos los estados.
 * Cada estado concreto sobrescribe solo las acciones permitidas.
 */
public abstract class EstadoPedidoBase implements EstadoPedido {

    @Override
    public void pagar(Pedido pedido) {
        throw new IllegalStateException("No se puede pagar desde el estado " + getNombre());
    }

    @Override
    public void preparar(Pedido pedido) {
        throw new IllegalStateException("No se puede preparar desde el estado " + getNombre());
    }

    @Override
    public void entregar(Pedido pedido) {
        throw new IllegalStateException("No se puede entregar desde el estado " + getNombre());
    }

    @Override
    public void cancelar(Pedido pedido) {
        throw new IllegalStateException("No se puede cancelar desde el estado " + getNombre());
    }
}
