package com.uade.magiccafe.domain.model;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/*
 * Relación interna del Composite.
 * Ejemplo: Combo Desayuno Mágico contiene 1 Café Latte y 2 Croissants.
 */
@Entity
@Table(name = "combo_items")
public class ComboItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "combo_id", nullable = false)
    private Combo combo;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "vendible_id", nullable = false)
    private Vendible vendible;

    private int cantidad;

    protected ComboItem() {
    }

    public ComboItem(Combo combo, Vendible vendible, int cantidad) {
        this.combo = combo;
        this.vendible = vendible;
        this.cantidad = cantidad;
    }

    public double calcularSubtotal() {
        return vendible.calcularPrecio() * cantidad;
    }

    public Vendible getVendible() {
        return vendible;
    }

    public int getCantidad() {
        return cantidad;
    }
}
