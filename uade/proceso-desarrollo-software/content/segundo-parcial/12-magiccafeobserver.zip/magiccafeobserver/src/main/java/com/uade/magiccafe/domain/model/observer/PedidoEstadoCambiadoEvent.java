package com.uade.magiccafe.domain.model.observer;

import com.uade.magiccafe.domain.model.Pedido;

import java.time.LocalDateTime;

public class PedidoEstadoCambiadoEvent {

    private final Pedido pedido;
    private final String estadoAnterior;
    private final String estadoNuevo;
    private final LocalDateTime fechaCambio;

    public PedidoEstadoCambiadoEvent(
            Pedido pedido,
            String estadoAnterior,
            String estadoNuevo) {
        this.pedido = pedido;
        this.estadoAnterior = estadoAnterior;
        this.estadoNuevo = estadoNuevo;
        this.fechaCambio = LocalDateTime.now();
    }

    public Pedido getPedido() {
        return pedido;
    }

    public Long getPedidoId() {
        return pedido.getId();
    }

    public String getEstadoAnterior() {
        return estadoAnterior;
    }

    public String getEstadoNuevo() {
        return estadoNuevo;
    }

    public LocalDateTime getFechaCambio() {
        return fechaCambio;
    }

    public double getTotalPedido() {
        return pedido.getTotal();
    }
}
