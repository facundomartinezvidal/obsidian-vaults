package com.uade.magiccafe.application.dto;

public class PedidoConfirmadoDTO {

    private final Long id;
    private final double subtotal;
    private final String descuento;
    private final double total;

    public PedidoConfirmadoDTO(Long id, double subtotal, String descuento, double total) {
        this.id = id;
        this.subtotal = subtotal;
        this.descuento = descuento;
        this.total = total;
    }

    public Long getId() {
        return id;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public String getDescuento() {
        return descuento;
    }

    public double getTotal() {
        return total;
    }
}
