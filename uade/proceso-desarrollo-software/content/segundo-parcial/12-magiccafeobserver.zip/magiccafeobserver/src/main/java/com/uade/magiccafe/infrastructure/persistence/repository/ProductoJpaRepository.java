package com.uade.magiccafe.infrastructure.persistence.repository;

import com.uade.magiccafe.domain.model.Producto;
import com.uade.magiccafe.domain.repository.ProductoRepository;

/*
 * No reimplementa save(), findAll(), findById(), delete().
 * Hereda todo desde SimpleJpaRepository.
 */
public class ProductoJpaRepository
        extends SimpleJpaRepository<Producto, Long>
        implements ProductoRepository {

    public ProductoJpaRepository() {
        super(Producto.class);
    }
}
