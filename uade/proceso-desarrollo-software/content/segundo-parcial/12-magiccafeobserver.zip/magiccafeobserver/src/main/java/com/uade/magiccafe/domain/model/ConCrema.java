package com.uade.magiccafe.domain.model;

/*
 * Decorator concreto.
 * Agrega crema al item base.
 */
public class ConCrema extends VendibleDecorator {

    private static final double PRECIO_EXTRA = 500;

    public ConCrema(ItemVendible itemVendible) {
        super(itemVendible);
    }

    @Override
    public String getNombre() {
        return itemVendible.getNombre() + " + crema";
    }

    @Override
    public double calcularPrecio() {
        return itemVendible.calcularPrecio() + PRECIO_EXTRA;
    }
}
