package com.uade.magiccafe.domain.model;

/*
 * Decorator Pattern - Component
 *
 * Representa cualquier item que puede agregarse al pedido.
 * Puede ser un Vendible real del catalogo o un vendible decorado con extras.
 */
public interface ItemVendible {

    String getNombre();

    double calcularPrecio();
}
