package com.uade.magiccafe.domain.model;

/*
 * Decorator concreto.
 * Agrega leche al item base.
 */
public class ConLeche extends VendibleDecorator {

    private static final double PRECIO_EXTRA = 300;

    public ConLeche(ItemVendible itemVendible) {
        super(itemVendible);
    }

    @Override
    public String getNombre() {
        return itemVendible.getNombre() + " + leche";
    }

    @Override
    public double calcularPrecio() {
        return itemVendible.calcularPrecio() + PRECIO_EXTRA;
    }
}
