package com.uade.magiccafe.domain.repository;

import java.util.List;
import java.util.Optional;

/*
 * Versión didáctica, estilo Spring Data JpaRepository, pero hecha en Java SE.
 *
 * La aplicación trabaja contra esta interfaz y no contra EntityManager.
 * Las clases concretas de infraestructura implementan estos métodos usando Hibernate/JPA.
 */
public interface JpaRepository<T, ID> {

    T save(T entity);

    Optional<T> findById(ID id);

    List<T> findAll();

    void delete(T entity);

    void deleteById(ID id);
}
