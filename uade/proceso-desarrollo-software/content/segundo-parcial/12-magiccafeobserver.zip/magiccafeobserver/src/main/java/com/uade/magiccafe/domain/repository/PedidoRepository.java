package com.uade.magiccafe.domain.repository;

import com.uade.magiccafe.domain.model.Pedido;

import java.util.List;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    List<Pedido> findAllOrderByFechaCreacionDesc();
}
