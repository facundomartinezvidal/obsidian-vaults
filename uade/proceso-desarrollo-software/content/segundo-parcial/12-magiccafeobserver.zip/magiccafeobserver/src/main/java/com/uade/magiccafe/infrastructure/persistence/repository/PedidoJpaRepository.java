package com.uade.magiccafe.infrastructure.persistence.repository;

import com.uade.magiccafe.domain.model.Pedido;
import com.uade.magiccafe.domain.repository.PedidoRepository;
import com.uade.magiccafe.infrastructure.persistence.jpa.JPAUtil;
import jakarta.persistence.EntityManager;

import java.util.List;

/*
 * Hereda CRUD común desde SimpleJpaRepository.
 * Solo agrega un método específico de Pedido:
 * findAllOrderByFechaCreacionDesc().
 */
public class PedidoJpaRepository
        extends SimpleJpaRepository<Pedido, Long>
        implements PedidoRepository {

    public PedidoJpaRepository() {
        super(Pedido.class);
    }

    @Override
    public List<Pedido> findAllOrderByFechaCreacionDesc() {
        EntityManager em = JPAUtil.getEntityManager();

        try {
            return em.createQuery(
                    "FROM Pedido p ORDER BY p.fechaCreacion DESC, p.id DESC",
                    Pedido.class
            ).getResultList();

        } finally {
            em.close();
        }
    }
}
