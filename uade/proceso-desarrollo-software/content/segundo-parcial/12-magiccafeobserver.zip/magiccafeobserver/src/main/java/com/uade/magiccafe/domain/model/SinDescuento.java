package com.uade.magiccafe.domain.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("SIN_DESCUENTO")
public class SinDescuento extends DescuentoStrategy {

    public SinDescuento() {
    }

    @Override
    public String getNombre() {
        return "Sin descuento";
    }

    @Override
    public double aplicar(double subtotal) {
        return subtotal;
    }
}
