package com.uade.magiccafe.domain.repository;

import com.uade.magiccafe.domain.model.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
}
