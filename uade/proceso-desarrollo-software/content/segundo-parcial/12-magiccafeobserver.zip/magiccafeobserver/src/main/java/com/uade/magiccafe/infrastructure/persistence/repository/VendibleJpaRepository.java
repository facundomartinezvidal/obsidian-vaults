package com.uade.magiccafe.infrastructure.persistence.repository;

import com.uade.magiccafe.domain.model.Vendible;
import com.uade.magiccafe.domain.repository.VendibleRepository;

public class VendibleJpaRepository
        extends SimpleJpaRepository<Vendible, Long>
        implements VendibleRepository {

    public VendibleJpaRepository() {
        super(Vendible.class);
    }
}
