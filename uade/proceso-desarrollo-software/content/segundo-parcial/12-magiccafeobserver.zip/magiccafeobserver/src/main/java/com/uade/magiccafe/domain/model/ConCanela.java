package com.uade.magiccafe.domain.model;

/*
 * Decorator concreto.
 * Agrega canela al item base.
 */
public class ConCanela extends VendibleDecorator {

    private static final double PRECIO_EXTRA = 150;

    public ConCanela(ItemVendible itemVendible) {
        super(itemVendible);
    }

    @Override
    public String getNombre() {
        return itemVendible.getNombre() + " + canela";
    }

    @Override
    public double calcularPrecio() {
        return itemVendible.calcularPrecio() + PRECIO_EXTRA;
    }
}
