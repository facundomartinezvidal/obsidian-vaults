package com.uade.magiccafe.domain.model;

import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;

@Entity
@Table(name = "descuentos")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tipo_descuento")
public abstract class DescuentoStrategy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    protected DescuentoStrategy() {
    }

    public Long getId() {
        return id;
    }

    public abstract String getNombre();

    public abstract double aplicar(double subtotal);

    @Override
    public String toString() {
        return getNombre();
    }
}
