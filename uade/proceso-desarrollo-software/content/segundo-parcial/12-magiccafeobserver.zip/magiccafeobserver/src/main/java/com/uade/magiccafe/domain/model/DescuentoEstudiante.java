package com.uade.magiccafe.domain.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("ESTUDIANTE")
public class DescuentoEstudiante extends DescuentoStrategy {

    private double porcentaje;

    protected DescuentoEstudiante() {
    }

    public DescuentoEstudiante(double porcentaje) {
        this.porcentaje = porcentaje;
    }

    @Override
    public String getNombre() {
        return "Descuento estudiante " + porcentaje + "%";
    }

    @Override
    public double aplicar(double subtotal) {
        return subtotal - (subtotal * porcentaje / 100);
    }
}
