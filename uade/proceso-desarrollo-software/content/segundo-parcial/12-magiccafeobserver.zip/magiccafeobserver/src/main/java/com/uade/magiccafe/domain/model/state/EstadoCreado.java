package com.uade.magiccafe.domain.model.state;

import com.uade.magiccafe.domain.model.Pedido;

public class EstadoCreado extends EstadoPedidoBase {

    @Override
    public String getNombre() {
        return "CREADO";
    }

    @Override
    public void pagar(Pedido pedido) {
        pedido.cambiarEstado(new EstadoPagado());
    }

    @Override
    public void cancelar(Pedido pedido) {
        pedido.cambiarEstado(new EstadoCancelado());
    }
}
