package com.uade.magiccafe.presentation.ui;

import com.uade.magiccafe.application.dto.DescuentoDTO;
import com.uade.magiccafe.application.dto.PedidoConfirmadoDTO;
import com.uade.magiccafe.application.dto.PedidoResumenDTO;
import com.uade.magiccafe.application.dto.VendibleDTO;
import com.uade.magiccafe.presentation.controller.MagicCafeController;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.time.format.DateTimeFormatter;

public class MagicCafeFrame extends JFrame {

    private final MagicCafeController controller;

    private final JComboBox<VendibleDTO> vendiblesCombo = new JComboBox<>();
    private final JComboBox<DescuentoDTO> descuentosCombo = new JComboBox<>();
    private final JTextField cantidadField = new JTextField("1");

    private final DefaultTableModel pedidoModel = new DefaultTableModel(
            new Object[]{"Vendible ID", "Tipo", "Nombre", "Cantidad"},
            0
    );

    private final DefaultTableModel pedidosDbModel = new DefaultTableModel(
            new Object[]{"ID", "Fecha", "Subtotal", "Descuento", "Total"},
            0
    );

    private final JTable pedidoTable = new JTable(pedidoModel);
    private final JTable pedidosDbTable = new JTable(pedidosDbModel);

    private final JLabel mensajeLabel =
            new JLabel("Clean Architecture + Hibernate/JPA + Strategy + Composite");

    public MagicCafeFrame(MagicCafeController controller) {
        this.controller = controller;

        setTitle("MagicCafe - Clean Architecture + Strategy + Composite");
        setSize(1200, 740);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        construirUI();
        cargarDatosIniciales();
    }

    private void construirUI() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBorder(new EmptyBorder(16, 16, 16, 16));
        root.setBackground(new Color(245, 241, 255));

        JLabel titulo = new JLabel(
                "☕✨ MagicCafe - Strategy + Composite + JpaRepository sin Spring Boot ✨☕",
                SwingConstants.CENTER
        );
        titulo.setFont(new Font("SansSerif", Font.BOLD, 24));
        titulo.setForeground(new Color(70, 40, 120));

        root.add(titulo, BorderLayout.NORTH);
        root.add(crearPanelPedido(), BorderLayout.WEST);
        root.add(crearPanelPedidosPersistidos(), BorderLayout.CENTER);

        mensajeLabel.setFont(new Font("SansSerif", Font.ITALIC, 14));
        mensajeLabel.setForeground(new Color(70, 40, 120));
        root.add(mensajeLabel, BorderLayout.SOUTH);

        setContentPane(root);
    }

    private JPanel crearPanelPedido() {
        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setBackground(new Color(250, 248, 255));
        left.setBorder(BorderFactory.createTitledBorder("Crear pedido"));

        vendiblesCombo.setMaximumSize(new Dimension(420, 32));
        descuentosCombo.setMaximumSize(new Dimension(420, 32));
        cantidadField.setMaximumSize(new Dimension(420, 32));

        left.add(new JLabel("Vendible (Producto o Combo - Composite)"));
        left.add(vendiblesCombo);
        left.add(Box.createVerticalStrut(8));

        left.add(new JLabel("Cantidad"));
        left.add(cantidadField);
        left.add(Box.createVerticalStrut(8));

        JButton agregarButton = new JButton("Agregar item");
        agregarButton.addActionListener(e -> agregarItem());
        left.add(agregarButton);
        left.add(Box.createVerticalStrut(12));

        left.add(new JLabel("Descuento / Strategy persistida"));
        left.add(descuentosCombo);
        left.add(Box.createVerticalStrut(12));

        JScrollPane pedidoScroll = new JScrollPane(pedidoTable);
        pedidoScroll.setPreferredSize(new Dimension(420, 240));
        pedidoScroll.setBorder(BorderFactory.createTitledBorder("Items del pedido actual"));

        left.add(pedidoScroll);
        left.add(Box.createVerticalStrut(12));

        JButton confirmarButton = new JButton("Confirmar pedido y guardar");
        confirmarButton.addActionListener(e -> confirmarPedido());
        left.add(confirmarButton);

        JButton vaciarButton = new JButton("Vaciar pedido actual");
        vaciarButton.addActionListener(e -> vaciarPedido());
        left.add(vaciarButton);

        return left;
    }

    private JPanel crearPanelPedidosPersistidos() {
        JPanel center = new JPanel(new BorderLayout(8, 8));
        center.setBackground(new Color(250, 248, 255));
        center.setBorder(BorderFactory.createTitledBorder("Pedidos persistidos"));

        JButton recargarButton = new JButton("Recargar pedidos desde DB");
        recargarButton.addActionListener(e -> cargarPedidosDesdeDb());

        center.add(new JScrollPane(pedidosDbTable), BorderLayout.CENTER);
        center.add(recargarButton, BorderLayout.SOUTH);

        return center;
    }

    private void cargarDatosIniciales() {
        try {
            controller.inicializarDatosBase();

            vendiblesCombo.removeAllItems();

            for (VendibleDTO vendible : controller.listarVendibles()) {
                vendiblesCombo.addItem(vendible);
            }

            descuentosCombo.removeAllItems();

            for (DescuentoDTO descuento : controller.listarDescuentos()) {
                descuentosCombo.addItem(descuento);
            }

            cargarPedidosDesdeDb();

        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarError(ex.getMessage());
        }
    }

    private void agregarItem() {
        try {
            VendibleDTO vendible = (VendibleDTO) vendiblesCombo.getSelectedItem();
            int cantidad = Integer.parseInt(cantidadField.getText());

            if (vendible == null) {
                throw new RuntimeException("Debe seleccionar un vendible");
            }

            controller.agregarItem(vendible.getId(), cantidad);

            pedidoModel.addRow(new Object[]{
                    vendible.getId(),
                    vendible.getTipo(),
                    vendible.getNombre(),
                    cantidad
            });

            mensajeLabel.setText("Item agregado: " + vendible.getNombre());

        } catch (Exception ex) {
            mostrarError(ex.getMessage());
        }
    }

    private void confirmarPedido() {
        try {
            DescuentoDTO descuento = (DescuentoDTO) descuentosCombo.getSelectedItem();

            if (descuento == null) {
                throw new RuntimeException("Debe seleccionar descuento");
            }

            PedidoConfirmadoDTO confirmado =
                    controller.confirmarPedido(descuento.getId());

            pedidoModel.setRowCount(0);
            cargarPedidosDesdeDb();

            JOptionPane.showMessageDialog(
                    this,
                    "Pedido guardado. ID: " + confirmado.getId()
                            + "\nSubtotal: $" + confirmado.getSubtotal()
                            + "\nDescuento: " + confirmado.getDescuento()
                            + "\nTotal: $" + confirmado.getTotal()
            );

            mensajeLabel.setText(
                    "Pedido guardado correctamente. ID: " + confirmado.getId()
            );

        } catch (Exception ex) {
            mostrarError(ex.getMessage());
        }
    }

    private void vaciarPedido() {
        controller.vaciarPedido();
        pedidoModel.setRowCount(0);
        mensajeLabel.setText("Pedido actual vaciado");
    }

    private void cargarPedidosDesdeDb() {
        pedidosDbModel.setRowCount(0);

        DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        for (PedidoResumenDTO pedido : controller.listarPedidos()) {
            pedidosDbModel.addRow(new Object[]{
                    pedido.getId(),
                    pedido.getFechaCreacion() != null
                            ? pedido.getFechaCreacion().format(formatter)
                            : "",
                    pedido.getSubtotal(),
                    pedido.getDescuento(),
                    pedido.getTotal()
            });
        }
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(
                this,
                mensaje,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );

        mensajeLabel.setText("Error: " + mensaje);
    }
}
