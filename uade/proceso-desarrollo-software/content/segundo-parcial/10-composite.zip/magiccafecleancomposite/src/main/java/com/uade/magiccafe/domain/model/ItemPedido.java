package com.uade.magiccafe.domain.model;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "pedido_items")
public class ItemPedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pedido_id", nullable = false)
    private Pedido pedido;

    /*
     * Composite aplicado al pedido:
     * un ItemPedido puede vender tanto un Producto simple como un Combo.
     */
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "vendible_id", nullable = false)
    private Vendible vendible;

    private int cantidad;
    private double precioUnitario;
    private double subtotal;

    protected ItemPedido() {
    }

    public ItemPedido(Pedido pedido, Vendible vendible, int cantidad) {
        if (pedido == null) {
            throw new IllegalArgumentException("El pedido es obligatorio");
        }

        if (vendible == null) {
            throw new IllegalArgumentException("El vendible es obligatorio");
        }

        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor a cero");
        }

        this.pedido = pedido;
        this.vendible = vendible;
        this.cantidad = cantidad;
        this.precioUnitario = vendible.calcularPrecio();
        this.subtotal = precioUnitario * cantidad;
    }

    public Vendible getVendible() {
        return vendible;
    }

    public String getNombreVendible() {
        return vendible.getNombre();
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public double getSubtotal() {
        return subtotal;
    }
}
