package com.uade.magiccafe.domain.model.factory;

import com.uade.magiccafe.domain.model.Combo;
import com.uade.magiccafe.domain.model.Producto;
import com.uade.magiccafe.domain.model.Vendible;

/*
 * Concrete Factory
 * Crea la familia de objetos relacionada con una merienda.
 */
public class MeriendaMagicaFactory implements MenuMagicoFactory {

    @Override
    public Producto crearBebida() {
        return new Producto("🍵 Té de hierbas encantadas", 3900);
    }

    @Override
    public Producto crearAcompanamiento() {
        return new Producto("🍪 Cookie de chocolate", 3100);
    }

    @Override
    public Producto crearPostre() {
        return new Producto("🍰 Torta encantada", 5800);
    }

    @Override
    public Combo crearCombo(Vendible bebida, Vendible acompanamiento, Vendible postre) {
        Combo combo = new Combo("🍰 Combo Merienda Mágica");
        combo.agregarVendible(bebida, 1);
        combo.agregarVendible(acompanamiento, 1);
        combo.agregarVendible(postre, 1);
        return combo;
    }
}
