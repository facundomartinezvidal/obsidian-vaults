package com.uade.magiccafe.domain.model.factory;

import com.uade.magiccafe.domain.model.Combo;
import com.uade.magiccafe.domain.model.Producto;
import com.uade.magiccafe.domain.model.Vendible;

/*
 * Concrete Factory
 * Crea la familia de objetos relacionada con un desayuno.
 */
public class DesayunoMagicoFactory implements MenuMagicoFactory {

    @Override
    public Producto crearBebida() {
        return new Producto("☕ Café Latte", 4500);
    }

    @Override
    public Producto crearAcompanamiento() {
        return new Producto("🥐 Croissant mágico", 3200);
    }

    @Override
    public Producto crearPostre() {
        return new Producto("🧁 Muffin de vainilla", 3600);
    }

    @Override
    public Combo crearCombo(Vendible bebida, Vendible acompanamiento, Vendible postre) {
        Combo combo = new Combo("✨ Combo Desayuno Mágico");
        combo.agregarVendible(bebida, 1);
        combo.agregarVendible(acompanamiento, 2);
        combo.agregarVendible(postre, 1);
        return combo;
    }
}
