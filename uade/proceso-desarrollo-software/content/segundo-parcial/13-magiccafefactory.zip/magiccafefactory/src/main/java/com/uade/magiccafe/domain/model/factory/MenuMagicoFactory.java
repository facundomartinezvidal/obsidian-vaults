package com.uade.magiccafe.domain.model.factory;

import com.uade.magiccafe.domain.model.Combo;
import com.uade.magiccafe.domain.model.Producto;
import com.uade.magiccafe.domain.model.Vendible;

/*
 * Abstract Factory
 * Define una familia de productos compatibles para un menú de Magic Café.
 *
 * La aplicación no necesita conocer qué Producto concreto corresponde a cada
 * tipo de menú. Solo pide la familia: bebida, acompañamiento, postre y combo.
 */
public interface MenuMagicoFactory {

    Producto crearBebida();

    Producto crearAcompanamiento();

    Producto crearPostre();

    Combo crearCombo(Vendible bebida, Vendible acompanamiento, Vendible postre);
}
