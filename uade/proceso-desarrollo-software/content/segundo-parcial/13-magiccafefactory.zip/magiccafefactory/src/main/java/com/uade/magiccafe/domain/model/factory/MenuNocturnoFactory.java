package com.uade.magiccafe.domain.model.factory;

import com.uade.magiccafe.domain.model.Combo;
import com.uade.magiccafe.domain.model.Producto;
import com.uade.magiccafe.domain.model.Vendible;

/*
 * Concrete Factory
 * Crea la familia de objetos relacionada con un menú premium/nocturno.
 */
public class MenuNocturnoFactory implements MenuMagicoFactory {

    @Override
    public Producto crearBebida() {
        return new Producto("🍫 Chocolate nocturno", 5200);
    }

    @Override
    public Producto crearAcompanamiento() {
        return new Producto("🥯 Bagel lunar", 4200);
    }

    @Override
    public Producto crearPostre() {
        return new Producto("🍮 Flan de caramelo mágico", 5000);
    }

    @Override
    public Combo crearCombo(Vendible bebida, Vendible acompanamiento, Vendible postre) {
        Combo combo = new Combo("🌙 Combo Nocturno Premium");
        combo.agregarVendible(bebida, 1);
        combo.agregarVendible(acompanamiento, 1);
        combo.agregarVendible(postre, 1);
        return combo;
    }
}
