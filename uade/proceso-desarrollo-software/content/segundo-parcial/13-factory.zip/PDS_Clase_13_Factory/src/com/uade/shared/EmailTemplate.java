package com.uade.shared;

public class EmailTemplate implements ITemplate {
    @Override
    public void format() {
        System.out.println("Formatting Email");
    }
}
