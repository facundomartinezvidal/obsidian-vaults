package com.uade.shared;

public interface ITemplate {
    void format();
}
