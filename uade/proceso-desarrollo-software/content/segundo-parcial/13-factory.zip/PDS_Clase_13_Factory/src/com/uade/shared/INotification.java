package com.uade.shared;

public interface INotification {
    void send();
}
