package com.uade.abstractfactory;

public class AbstractFactoryDemo {
	public static void ejecutar() {
        System.out.println("\n--- PASO 3: ABSTRACT FACTORY ---");
        
        OrderService orderServiceClient = new OrderService();
        orderServiceClient.sendNotification();

        DeliveryService deliveryServiceClient = new DeliveryService();
        deliveryServiceClient.sendNotification();
    }
}
