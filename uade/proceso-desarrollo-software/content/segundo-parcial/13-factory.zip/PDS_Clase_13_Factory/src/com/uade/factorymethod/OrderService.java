package com.uade.factorymethod;

import com.uade.shared.EmailNotification;
import com.uade.shared.INotification;
import com.uade.shared.SmsNotification;

public class OrderService {
	public void sendNotification() {
        INotification notification = crearNotificacion("SMS");
        notification.send();
    }
	
	public static INotification crearNotificacion(String tipo) {
		INotification notificacionElegida = null;
		
		switch(tipo) {
			case "SMS": notificacionElegida = new SmsNotification(); break;
			case "EMAIL": notificacionElegida = new EmailNotification(); break;
		}
		
		return notificacionElegida;
	}
}
