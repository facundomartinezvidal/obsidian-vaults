package com.uade.factorymethod;

import com.uade.shared.EmailNotification;
import com.uade.shared.INotification;
import com.uade.shared.SmsNotification;

public class FactoryMethodDemo {
	public static void ejecutar() {
        System.out.println("\n--- PASO 1: FACTORY METHOD ---");
        
        OrderService orderServiceClient = new OrderService();
        orderServiceClient.sendNotification();

        DeliveryService deliveryServiceClient = new DeliveryService();
        deliveryServiceClient.sendNotification();
    }
}
