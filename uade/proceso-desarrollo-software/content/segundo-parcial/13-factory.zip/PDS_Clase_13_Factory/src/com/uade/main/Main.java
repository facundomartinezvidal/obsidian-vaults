package com.uade.main;

import com.uade.abstractfactory.AbstractFactoryDemo;
import com.uade.factorymethod.FactoryMethodDemo;
import com.uade.simplefactory.SimpleFactoryDemo;

public class Main {
	public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println(" FACTORY PATTERNS - DEMO ");
        System.out.println("========================================\n");

        FactoryMethodDemo.ejecutar();
        SimpleFactoryDemo.ejecutar();
        AbstractFactoryDemo.ejecutar();
    }
}