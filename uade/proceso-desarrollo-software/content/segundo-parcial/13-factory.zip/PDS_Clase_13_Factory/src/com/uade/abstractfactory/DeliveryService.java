package com.uade.abstractfactory;
import com.uade.shared.INotification;
import com.uade.shared.ITemplate;

public class DeliveryService {

    public void sendNotification() {
        INotificationFactory factory = new EmailFactory();
        INotification notification = factory.createNotification();
        ITemplate template = factory.createTemplate();
        notification.send();
        template.format();
    }
}
