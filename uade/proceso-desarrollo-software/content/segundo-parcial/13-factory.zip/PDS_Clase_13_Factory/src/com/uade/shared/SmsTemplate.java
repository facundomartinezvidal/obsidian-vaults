package com.uade.shared;
public class SmsTemplate implements ITemplate{
    @Override
    public void format() {
        System.out.println("Formatting Sms");
    }
}
