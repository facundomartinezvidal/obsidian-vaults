package com.uade.shared;

public class EmailNotification implements INotification{
    public void send() {
        System.out.println("Sending Email");
    }
}
