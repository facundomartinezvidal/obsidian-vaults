package com.uade.abstractfactory;
import com.uade.shared.EmailNotification;
import com.uade.shared.EmailTemplate;
import com.uade.shared.INotification;
import com.uade.shared.ITemplate;

public class EmailFactory implements INotificationFactory{
    @Override
    public INotification createNotification() {
        return new EmailNotification();
    }

    @Override
    public ITemplate createTemplate() {
        return new EmailTemplate();
    }
}
