package com.uade.simplefactory;

import com.uade.shared.INotification;

public class OrderService {
	public void sendNotification() {
        INotification notification = NotificationFactory.crearNotificacion("SMS");
        notification.send();
    }
}
