package com.uade.abstractfactory;
import com.uade.shared.INotification;
import com.uade.shared.ITemplate;

public interface INotificationFactory {
    INotification createNotification();
    ITemplate createTemplate();
}
