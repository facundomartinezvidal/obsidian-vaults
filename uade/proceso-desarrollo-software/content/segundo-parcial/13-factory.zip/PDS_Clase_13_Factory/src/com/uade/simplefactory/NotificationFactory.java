package com.uade.simplefactory;

import com.uade.shared.EmailNotification;
import com.uade.shared.INotification;
import com.uade.shared.SmsNotification;

public class NotificationFactory {
	public static INotification crearNotificacion(String tipo) {
		INotification notificacionElegida = null;
		
		switch(tipo) {
			case "SMS": notificacionElegida = new SmsNotification(); break;
			case "EMAIL": notificacionElegida = new EmailNotification(); break;
		}
		
		return notificacionElegida;
	}
}
