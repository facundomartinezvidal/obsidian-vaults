package com.uade.shared;
public class SmsNotification implements INotification{
    public void send() {
        System.out.println("Sending SMS");
    }
}
