package com.uade.simplefactory;

import com.uade.shared.INotification;

public class DeliveryService {
	public void sendNotification() {
        INotification notification = NotificationFactory.crearNotificacion("EMAIL");
        notification.send();
    }
}
