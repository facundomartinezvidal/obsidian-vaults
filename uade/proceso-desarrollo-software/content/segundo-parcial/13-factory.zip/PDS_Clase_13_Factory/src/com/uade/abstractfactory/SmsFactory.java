package com.uade.abstractfactory;
import com.uade.shared.INotification;
import com.uade.shared.ITemplate;
import com.uade.shared.SmsNotification;
import com.uade.shared.SmsTemplate;

public class SmsFactory implements INotificationFactory{
    @Override
    public INotification createNotification() {
        return new SmsNotification();
    }

    @Override
    public ITemplate createTemplate() {
        return new SmsTemplate();
    }
}
