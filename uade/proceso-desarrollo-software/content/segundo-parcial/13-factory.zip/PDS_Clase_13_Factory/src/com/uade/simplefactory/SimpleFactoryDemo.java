package com.uade.simplefactory;

import com.uade.factorymethod.DeliveryService;
import com.uade.factorymethod.OrderService;

public class SimpleFactoryDemo {
	public static void ejecutar() {
        System.out.println("\n--- PASO 2: SIMPLE FACTORY ---");
        
        OrderService orderServiceClient = new OrderService();
        orderServiceClient.sendNotification();

        DeliveryService deliveryServiceClient = new DeliveryService();
        deliveryServiceClient.sendNotification();
    }
}
