package com.uade.magiccafe.domain.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "pedidos")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime fechaCreacion;

    private double subtotal;

    private double total;

    @ManyToOne(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    @JoinColumn(name = "descuento_id", nullable = false)
    private DescuentoStrategy descuento;

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ItemPedido> items = new ArrayList<>();

    protected Pedido() {
    }

    public Pedido(DescuentoStrategy descuento) {
        if (descuento == null) {
            throw new IllegalArgumentException("El descuento es obligatorio");
        }

        this.fechaCreacion = LocalDateTime.now();
        this.descuento = descuento;
    }

    /*
     * Composite + Decorator:
     * - vendibleBase: Producto o Combo persistido en catalogo.
     * - itemDecorado: objeto decorado en memoria con extras.
     */
    public void agregarItem(
            Vendible vendibleBase,
            ItemVendible itemDecorado,
            String extrasAplicados,
            int cantidad) {
        ItemPedido item = new ItemPedido(
                this,
                vendibleBase,
                itemDecorado,
                extrasAplicados,
                cantidad
        );

        items.add(item);
        recalcularTotales();
    }

    public void agregarVendible(Vendible vendible, int cantidad) {
        agregarItem(vendible, vendible, "Sin extras", cantidad);
    }

    public void recalcularTotales() {
        subtotal = items.stream()
                .mapToDouble(ItemPedido::getSubtotal)
                .sum();

        total = descuento.aplicar(subtotal);
    }

    public boolean estaVacio() {
        return items.isEmpty();
    }

    public Long getId() {
        return id;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public double getTotal() {
        return total;
    }

    public DescuentoStrategy getDescuento() {
        return descuento;
    }

    public List<ItemPedido> getItems() {
        return items;
    }
}
