package com.uade.magiccafe.application.dto;

import java.time.LocalDateTime;

public class PedidoResumenDTO {

    private final Long id;
    private final LocalDateTime fechaCreacion;
    private final double subtotal;
    private final String descuento;
    private final double total;

    public PedidoResumenDTO(
            Long id,
            LocalDateTime fechaCreacion,
            double subtotal,
            String descuento,
            double total) {
        this.id = id;
        this.fechaCreacion = fechaCreacion;
        this.subtotal = subtotal;
        this.descuento = descuento;
        this.total = total;
    }

    public Long getId() {
        return id;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public String getDescuento() {
        return descuento;
    }

    public double getTotal() {
        return total;
    }
}
