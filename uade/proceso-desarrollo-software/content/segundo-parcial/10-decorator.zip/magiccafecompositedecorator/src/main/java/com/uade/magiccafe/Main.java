package com.uade.magiccafe;

import com.uade.magiccafe.application.usecase.MagicCafeService;
import com.uade.magiccafe.domain.repository.DescuentoRepository;
import com.uade.magiccafe.domain.repository.PedidoRepository;
import com.uade.magiccafe.domain.repository.VendibleRepository;
import com.uade.magiccafe.infrastructure.persistence.jpa.JPAUtil;
import com.uade.magiccafe.infrastructure.persistence.repository.DescuentoJpaRepository;
import com.uade.magiccafe.infrastructure.persistence.repository.PedidoJpaRepository;
import com.uade.magiccafe.infrastructure.persistence.repository.VendibleJpaRepository;
import com.uade.magiccafe.presentation.controller.MagicCafeController;
import com.uade.magiccafe.presentation.ui.MagicCafeFrame;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {
        VendibleRepository vendibleRepository = new VendibleJpaRepository();
        PedidoRepository pedidoRepository = new PedidoJpaRepository();
        DescuentoRepository descuentoRepository = new DescuentoJpaRepository();

        MagicCafeService service = new MagicCafeService(
                vendibleRepository,
                pedidoRepository,
                descuentoRepository
        );

        MagicCafeController controller = new MagicCafeController(service);

        Runtime.getRuntime().addShutdownHook(new Thread(JPAUtil::close));

        SwingUtilities.invokeLater(
                () -> new MagicCafeFrame(controller).setVisible(true)
        );
    }
}
