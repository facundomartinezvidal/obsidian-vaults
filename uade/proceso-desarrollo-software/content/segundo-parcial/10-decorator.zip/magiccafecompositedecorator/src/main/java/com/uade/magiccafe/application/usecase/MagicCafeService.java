package com.uade.magiccafe.application.usecase;

import com.uade.magiccafe.application.dto.DescuentoDTO;
import com.uade.magiccafe.application.dto.PedidoConfirmadoDTO;
import com.uade.magiccafe.application.dto.PedidoResumenDTO;
import com.uade.magiccafe.application.dto.VendibleDTO;
import com.uade.magiccafe.domain.model.Combo;
import com.uade.magiccafe.domain.model.ConCanela;
import com.uade.magiccafe.domain.model.ConCrema;
import com.uade.magiccafe.domain.model.ConLeche;
import com.uade.magiccafe.domain.model.DescuentoEstudiante;
import com.uade.magiccafe.domain.model.DescuentoHechizo;
import com.uade.magiccafe.domain.model.DescuentoStrategy;
import com.uade.magiccafe.domain.model.ItemVendible;
import com.uade.magiccafe.domain.model.Pedido;
import com.uade.magiccafe.domain.model.Producto;
import com.uade.magiccafe.domain.model.SinDescuento;
import com.uade.magiccafe.domain.model.Vendible;
import com.uade.magiccafe.domain.repository.DescuentoRepository;
import com.uade.magiccafe.domain.repository.PedidoRepository;
import com.uade.magiccafe.domain.repository.VendibleRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MagicCafeService {

    private final VendibleRepository vendibleRepository;
    private final PedidoRepository pedidoRepository;
    private final DescuentoRepository descuentoRepository;

    public MagicCafeService(
            VendibleRepository vendibleRepository,
            PedidoRepository pedidoRepository,
            DescuentoRepository descuentoRepository) {
        this.vendibleRepository = vendibleRepository;
        this.pedidoRepository = pedidoRepository;
        this.descuentoRepository = descuentoRepository;
    }

    public void inicializarDatosBase() {
        if (vendibleRepository.findAll().isEmpty()) {
            Vendible cafeLatte = vendibleRepository.save(new Producto("☕ Café Latte", 4500));
            Vendible croissant = vendibleRepository.save(new Producto("🥐 Croissant mágico", 3200));
            Vendible torta = vendibleRepository.save(new Producto("🍰 Torta encantada", 5800));

            vendibleRepository.save(new Producto("🧃 Jugo de mandrágora", 3900));

            Combo desayunoMagico = new Combo("✨ Combo Desayuno Mágico");
            desayunoMagico.agregarVendible(cafeLatte, 1);
            desayunoMagico.agregarVendible(croissant, 2);
            vendibleRepository.save(desayunoMagico);

            Combo meriendaCompleta = new Combo("🍰 Combo Merienda Completa");
            meriendaCompleta.agregarVendible(cafeLatte, 1);
            meriendaCompleta.agregarVendible(torta, 1);
            vendibleRepository.save(meriendaCompleta);
        }

        if (descuentoRepository.findAll().isEmpty()) {
            descuentoRepository.save(new SinDescuento());
            descuentoRepository.save(new DescuentoEstudiante(15));
            descuentoRepository.save(new DescuentoHechizo(1000));
        }
    }

    public List<VendibleDTO> listarVendibles() {
        return vendibleRepository.findAll()
                .stream()
                .map(vendible -> new VendibleDTO(
                        vendible.getId(),
                        vendible.getNombre(),
                        vendible.calcularPrecio(),
                        vendible instanceof Combo ? "Combo" : "Producto"
                ))
                .collect(Collectors.toList());
    }

    public List<DescuentoDTO> listarDescuentos() {
        return descuentoRepository.findAll()
                .stream()
                .map(descuento -> new DescuentoDTO(
                        descuento.getId(),
                        descuento.getNombre()
                ))
                .collect(Collectors.toList());
    }

    public PedidoConfirmadoDTO confirmarPedido(
            List<ItemPedidoRequest> items,
            Long descuentoId) {
        if (items == null || items.isEmpty()) {
            throw new RuntimeException("No se puede confirmar un pedido vacío");
        }

        DescuentoStrategy descuento = descuentoRepository.findById(descuentoId)
                .orElseThrow(() -> new RuntimeException("Descuento no encontrado"));

        Pedido pedido = new Pedido(descuento);

        for (ItemPedidoRequest item : items) {
            Vendible vendibleBase = vendibleRepository.findById(item.getVendibleId())
                    .orElseThrow(() -> new RuntimeException("Vendible no encontrado"));

            ItemVendible itemDecorado = aplicarDecoradores(vendibleBase, item);
            String extrasAplicados = describirExtras(item);

            pedido.agregarItem(
                    vendibleBase,
                    itemDecorado,
                    extrasAplicados,
                    item.getCantidad()
            );
        }

        Pedido guardado = pedidoRepository.save(pedido);

        return new PedidoConfirmadoDTO(
                guardado.getId(),
                guardado.getSubtotal(),
                guardado.getDescuento().getNombre(),
                guardado.getTotal()
        );
    }

    public List<PedidoResumenDTO> listarPedidos() {
        return pedidoRepository.findAllOrderByFechaCreacionDesc()
                .stream()
                .map(pedido -> new PedidoResumenDTO(
                        pedido.getId(),
                        pedido.getFechaCreacion(),
                        pedido.getSubtotal(),
                        pedido.getDescuento().getNombre(),
                        pedido.getTotal()
                ))
                .collect(Collectors.toList());
    }

    private ItemVendible aplicarDecoradores(
            Vendible vendibleBase,
            ItemPedidoRequest request) {
        ItemVendible item = vendibleBase;

        if (request.isConLeche()) {
            item = new ConLeche(item);
        }

        if (request.isConCrema()) {
            item = new ConCrema(item);
        }

        if (request.isConCanela()) {
            item = new ConCanela(item);
        }

        return item;
    }

    private String describirExtras(ItemPedidoRequest request) {
        List<String> extras = new ArrayList<>();

        if (request.isConLeche()) {
            extras.add("leche");
        }

        if (request.isConCrema()) {
            extras.add("crema");
        }

        if (request.isConCanela()) {
            extras.add("canela");
        }

        if (extras.isEmpty()) {
            return "Sin extras";
        }

        return String.join(", ", extras);
    }

    public static class ItemPedidoRequest {

        private final Long vendibleId;
        private final int cantidad;
        private final boolean conLeche;
        private final boolean conCrema;
        private final boolean conCanela;

        public ItemPedidoRequest(
                Long vendibleId,
                int cantidad,
                boolean conLeche,
                boolean conCrema,
                boolean conCanela) {
            this.vendibleId = vendibleId;
            this.cantidad = cantidad;
            this.conLeche = conLeche;
            this.conCrema = conCrema;
            this.conCanela = conCanela;
        }

        public Long getVendibleId() {
            return vendibleId;
        }

        public int getCantidad() {
            return cantidad;
        }

        public boolean isConLeche() {
            return conLeche;
        }

        public boolean isConCrema() {
            return conCrema;
        }

        public boolean isConCanela() {
            return conCanela;
        }
    }
}
