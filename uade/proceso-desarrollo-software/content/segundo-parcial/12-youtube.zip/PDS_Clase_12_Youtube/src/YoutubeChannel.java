import java.util.ArrayList;
import java.util.List;

public class YoutubeChannel implements IObservable {
	private List<IObserver> subscriptores;
	private String lastVideo = "";
	
	YoutubeChannel() {
		subscriptores = new ArrayList<IObserver>();
    }
	
	@Override
	public void attach(IObserver o) {
		// TODO Auto-generated method stub
		subscriptores.add(o);
	}

	@Override
	public void detach(IObserver o) {
		// TODO Auto-generated method stub
		subscriptores.remove(o);
	}

	@Override
	public void notificar() {
		// TODO Auto-generated method stub
		for(IObserver subscriptor: subscriptores) 
			subscriptor.update();
	}
	
	public void addNewVideo(String title) {
		this.lastVideo = title;
		System.out.println("Nuevo video subido!");
		this.notificar();
	}
	
	public String getLastVideo() {
		return this.lastVideo;
	}
}
