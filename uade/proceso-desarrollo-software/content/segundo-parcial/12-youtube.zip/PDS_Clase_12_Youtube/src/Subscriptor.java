public class Subscriptor implements IObserver {
	private IObservable observado = null;
	private String nombre;
	
	Subscriptor(IObservable observado, String nombre){
		this.observado = observado;
		this.nombre = nombre;
	}
	
	@Override
	public void update() {
		// TODO Auto-generated method stub
		System.out.println("Hey " + nombre + "! New Video Posted: " 
							+ ((YoutubeChannel)observado).getLastVideo());
	}

}
