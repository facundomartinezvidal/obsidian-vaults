public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		YoutubeChannel channel = new YoutubeChannel();
		Subscriptor subs1 = new Subscriptor(channel, "Matias");
		Subscriptor subs2 = new Subscriptor(channel, "Fatima");
		
		channel.attach(subs1);
		channel.attach(subs2);

		channel.addNewVideo("He-Man: Masters of the Universe");

		channel.detach(subs2);

		channel.addNewVideo("Toy Story 5");
	}
}
